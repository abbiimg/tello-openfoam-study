// SPDX-FileCopyrightText: 2017 - 2026 The Ginkgo authors
//
// SPDX-License-Identifier: BSD-3-Clause

#include "core/multigrid/uniform_coarsening_kernels.hpp"

#include <ginkgo/core/base/math.hpp>

#include "common/unified/base/kernel_launch.hpp"
#include "common/unified/base/kernel_launch_reduction.hpp"
#include "core/components/prefix_sum_kernels.hpp"


namespace gko {
namespace kernels {
namespace GKO_DEVICE_NAMESPACE {
namespace uniform_coarsening {


template <typename ValueType, typename IndexType>
void fill_restrict_op(std::shared_ptr<const DefaultExecutor> exec,
                      const array<IndexType>* coarse_rows,
                      matrix::Csr<ValueType, IndexType>* restrict_op)
{
    run_kernel(
        exec,
        [] GKO_KERNEL(auto tidx, const auto coarse_data,
                      auto restrict_col_idxs) {
            if (coarse_data[tidx] >= 0) {
                restrict_col_idxs[coarse_data[tidx]] = tidx;
            }
        },
        coarse_rows->get_size(), coarse_rows->get_const_data(),
        restrict_op->get_col_idxs());
}

GKO_INSTANTIATE_FOR_EACH_VALUE_AND_INDEX_TYPE(
    GKO_DECLARE_UNIFORM_COARSENING_FILL_RESTRICT_OP);


template <typename IndexType>
void fill_incremental_indices(std::shared_ptr<const DefaultExecutor> exec,
                              size_type coarse_skip,
                              array<IndexType>* coarse_rows)
{
    const size_type num_elems = coarse_rows->get_size();
    const size_type num_iters = gko::ceildiv(num_elems, coarse_skip);
    run_kernel(
        exec,
        [] GKO_KERNEL(auto tidx, auto coarse_skip, auto coarse_data) {
            coarse_data[tidx * coarse_skip] = tidx;
        },
        num_iters, coarse_skip, coarse_rows->get_data());
}

GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(
    GKO_DECLARE_UNIFORM_COARSENING_FILL_INCREMENTAL_INDICES);


}  // namespace uniform_coarsening
}  // namespace GKO_DEVICE_NAMESPACE
}  // namespace kernels
}  // namespace gko
