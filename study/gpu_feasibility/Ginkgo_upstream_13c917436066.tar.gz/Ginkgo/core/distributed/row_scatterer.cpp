// SPDX-FileCopyrightText: 2017 - 2026 The Ginkgo authors
//
// SPDX-License-Identifier: BSD-3-Clause

#include "ginkgo/core/distributed/row_scatterer.hpp"

#include <ginkgo/core/base/dense_cache.hpp>
#include <ginkgo/core/distributed/dense_communicator.hpp>
#include <ginkgo/core/distributed/neighborhood_communicator.hpp>
#include <ginkgo/core/distributed/vector.hpp>
#include <ginkgo/core/matrix/dense.hpp>

#include "core/base/dispatch_helper.hpp"
#include "core/distributed/helpers.hpp"

namespace gko {
namespace experimental {
namespace distributed {


template <typename LocalIndexType>
void RowScatterer<LocalIndexType>::apply_async(
    ptr_param<const LinOp> local_values) const
{
    GKO_THROW_IF_INVALID(recv_buffer_ == nullptr,
                         "apply_async requires the previous scatter to be "
                         "finished by wait_and_accumulate.");
    auto exec = this->get_executor();
    auto use_host_buffer =
        mpi::requires_host_buffer(exec, coll_comm_->get_base_communicator());
    auto mpi_exec = use_host_buffer ? exec->get_master() : exec;

    // Dispatch on local_values as a distributed::Vector. It is not cloned to
    // another executor, since a temporary clone would be freed before the
    // communication finishes.
    run<Vector,
#if GINKGO_ENABLE_HALF
        half, std::complex<half>,
#endif
#if GINKGO_ENABLE_BFLOAT16
        bfloat16, std::complex<bfloat16>,
#endif
        double, float, std::complex<double>, std::complex<float>>(
        local_values.get(), [&](const auto* lv_global) {
            using ValueType =
                typename std::decay_t<decltype(*lv_global)>::value_type;
            auto lv_local = lv_global->get_local_vector();
            auto ncols = lv_local->get_size()[1];

            dim<2> send_size(coll_comm_->get_send_size(), ncols);
            GKO_ASSERT_EQUAL_DIMENSIONS(lv_local, send_size);
            const ValueType* send_ptr = nullptr;
            // send directly if MPI can access the memory of local_values,
            // otherwise pack it into the send buffer
            bool can_send_direct =
                mpi_exec->memory_accessible(lv_local->get_executor()) &&
                lv_local->get_stride() == static_cast<size_type>(ncols);
            if (can_send_direct) {
                send_ptr = lv_local->get_const_values();
            } else {
                auto send_buffer =
                    send_cache_.get<ValueType>(mpi_exec, send_size);
                lv_local->convert_to(send_buffer);
                send_ptr = send_buffer->get_const_values();
            }

            dim<2> recv_size(coll_comm_->get_recv_size(), ncols);
            auto recv_buffer = recv_cache_.get<ValueType>(mpi_exec, recv_size);

            // the send data has to be ready before MPI accesses it
            lv_local->get_executor()->synchronize();

            // Start async MPI communication
            mpi::contiguous_type type(ncols,
                                      mpi::type_impl<ValueType>::get_type());
            req_ = coll_comm_->i_all_to_all_v(mpi_exec, send_ptr, type.get(),
                                              recv_buffer->get_values(),
                                              type.get());
            recv_buffer_ = recv_buffer;
        });
}


template <typename LocalIndexType>
void RowScatterer<LocalIndexType>::wait_and_accumulate(
    ptr_param<LinOp> distributed_target) const
{
    GKO_THROW_IF_INVALID(recv_buffer_ != nullptr,
                         "wait_and_accumulate requires a preceding "
                         "apply_async.");
    req_.wait();
    auto recv_buffer_op = std::exchange(recv_buffer_, nullptr);

    // Dispatch on the distributed target to get ValueType
    run<Vector,
#if GINKGO_ENABLE_HALF
        half, std::complex<half>,
#endif
#if GINKGO_ENABLE_BFLOAT16
        bfloat16, std::complex<bfloat16>,
#endif
        double, float, std::complex<double>, std::complex<float>>(
        distributed_target.get(), [&](auto* target_global) {
            using ValueType =
                typename std::decay_t<decltype(*target_global)>::value_type;

            auto target_dense = gko::detail::get_local(target_global);
            // throws if apply_async used a different value type
            auto recv_buffer =
                gko::as<matrix::Dense<ValueType>>(recv_buffer_op);
            GKO_ASSERT_EQUAL_COLS(recv_buffer, target_dense);

            // scatter_add handles cross-executor copies via
            // make_temporary_clone
            target_dense->scatter_add(&recv_idxs_, recv_buffer.get());
        });
}


template <typename LocalIndexType>
dim<2> RowScatterer<LocalIndexType>::get_size() const
{
    return size_;
}


template <typename LocalIndexType>
std::shared_ptr<const mpi::CollectiveCommunicator>
RowScatterer<LocalIndexType>::get_collective_communicator() const
{
    return coll_comm_;
}


template <typename LocalIndexType>
const LocalIndexType* RowScatterer<LocalIndexType>::get_const_recv_idxs() const
{
    return recv_idxs_.get_const_data();
}


template <typename LocalIndexType>
size_type RowScatterer<LocalIndexType>::get_num_recv_idxs() const
{
    return recv_idxs_.get_size();
}


template <typename LocalIndexType>
template <typename GlobalIndexType>
RowScatterer<LocalIndexType>::RowScatterer(
    std::shared_ptr<const Executor> exec,
    std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm,
    const index_map<LocalIndexType, GlobalIndexType>& imap)
    : PolymorphicObject(exec),
      DistributedBase(coll_comm->get_base_communicator()),
      // transpose of the corresponding RowGatherer size
      size_(dim<2>{
          imap.get_global_size(),
          gko::detail::global_add(exec, coll_comm->get_base_communicator(),
                                  imap.get_non_local_size())}),
      coll_comm_(std::move(coll_comm)),
      recv_idxs_(exec)
{
    GKO_THROW_IF_INVALID(
        coll_comm_->get_recv_size() == imap.get_non_local_size(),
        "The collective communicator doesn't match the index map.");

    auto inverse_comm = coll_comm_->create_inverse();

    auto mpi_exec =
        mpi::requires_host_buffer(exec, coll_comm_->get_base_communicator())
            ? exec->get_master()
            : exec;
    auto temp_remote_local_idxs =
        make_temporary_clone(mpi_exec, &imap.get_remote_local_idxs());

    recv_idxs_.set_executor(mpi_exec);
    recv_idxs_.resize_and_reset(coll_comm_->get_send_size());
    inverse_comm
        ->i_all_to_all_v(mpi_exec,
                         temp_remote_local_idxs->get_const_flat_data(),
                         recv_idxs_.get_data())
        .wait();
    recv_idxs_.set_executor(exec);

    // Use the inverse comm for the actual scatter operation
    coll_comm_ = std::move(inverse_comm);
}


template <typename LocalIndexType>
std::unique_ptr<RowScatterer<LocalIndexType>>
RowScatterer<LocalIndexType>::create_from_gatherer(
    std::shared_ptr<const Executor> exec,
    ptr_param<const RowGatherer<LocalIndexType>> gatherer)
{
    auto inverse_comm =
        gatherer->get_collective_communicator()->create_inverse();

    // The recv_idxs_ for the scatterer are the send_idxs_ of the gatherer
    auto num_send_idxs = gatherer->get_num_send_idxs();
    array<LocalIndexType> recv_idxs(exec, num_send_idxs);
    if (num_send_idxs > 0) {
        exec->copy_from(gatherer->get_executor(), num_send_idxs,
                        gatherer->get_const_send_idxs(), recv_idxs.get_data());
    }

    // Size is the transpose of the gatherer's size
    auto gatherer_size = gatherer->get_size();
    dim<2> size{gatherer_size[1], gatherer_size[0]};

    return std::unique_ptr<RowScatterer>(new RowScatterer(
        std::move(exec), std::move(inverse_comm), std::move(recv_idxs), size));
}


template <typename LocalIndexType>
std::unique_ptr<RowScatterer<LocalIndexType>>
RowScatterer<LocalIndexType>::create(std::shared_ptr<const Executor> exec,
                                     mpi::communicator comm)
{
    return std::unique_ptr<RowScatterer>(
        new RowScatterer(std::move(exec), comm));
}


template <typename LocalIndexType>
RowScatterer<LocalIndexType>::RowScatterer(std::shared_ptr<const Executor> exec,
                                           mpi::communicator comm)
    : PolymorphicObject(exec),
      DistributedBase(comm),
      coll_comm_(mpi::detail::create_default_collective_communicator(comm)),
      recv_idxs_(exec)
{}


template <typename LocalIndexType>
RowScatterer<LocalIndexType>::RowScatterer(
    std::shared_ptr<const Executor> exec,
    std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm,
    array<LocalIndexType> recv_idxs, dim<2> size)
    : PolymorphicObject(exec),
      DistributedBase(coll_comm->get_base_communicator()),
      size_(size),
      coll_comm_(std::move(coll_comm)),
      recv_idxs_(std::move(recv_idxs))
{}


template <typename LocalIndexType>
RowScatterer<LocalIndexType>::RowScatterer(RowScatterer&& o)
    : PolymorphicObject(o.get_executor()),
      DistributedBase(o.get_communicator()),
      recv_idxs_(o.get_executor())
{
    *this = std::move(o);
}


template <typename LocalIndexType>
RowScatterer<LocalIndexType>& RowScatterer<LocalIndexType>::operator=(
    const RowScatterer& o)
{
    if (this != &o) {
        size_ = o.get_size();
        coll_comm_ = o.coll_comm_;
        recv_idxs_ = o.recv_idxs_;
    }
    return *this;
}


template <typename LocalIndexType>
RowScatterer<LocalIndexType>& RowScatterer<LocalIndexType>::operator=(
    RowScatterer&& o)
{
    if (this != &o) {
        size_ = std::exchange(o.size_, dim<2>{});
        coll_comm_ = std::exchange(
            o.coll_comm_, mpi::detail::create_default_collective_communicator(
                              o.get_communicator()));
        recv_idxs_ = std::move(o.recv_idxs_);
    }
    return *this;
}


template <typename LocalIndexType>
RowScatterer<LocalIndexType>::RowScatterer(const RowScatterer& o)
    : PolymorphicObject(o.get_executor()),
      DistributedBase(o.get_communicator()),
      recv_idxs_(o.get_executor())
{
    *this = o;
}


#define GKO_DECLARE_ROW_SCATTERER(IndexType) class RowScatterer<IndexType>

GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(GKO_DECLARE_ROW_SCATTERER);

#undef GKO_DECLARE_ROW_SCATTERER


#define GKO_DECLARE_ROW_SCATTERER_CONSTRUCTOR(_ltype, _gtype)         \
    RowScatterer<_ltype>::RowScatterer(                               \
        std::shared_ptr<const Executor> exec,                         \
        std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm, \
        const index_map<_ltype, _gtype>& imap)

GKO_INSTANTIATE_FOR_EACH_LOCAL_GLOBAL_INDEX_TYPE(
    GKO_DECLARE_ROW_SCATTERER_CONSTRUCTOR);

#undef GKO_DECLARE_ROW_SCATTERER_CONSTRUCTOR
}  // namespace distributed
}  // namespace experimental
}  // namespace gko
