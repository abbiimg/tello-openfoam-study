// SPDX-FileCopyrightText: 2017 - 2026 The Ginkgo authors
//
// SPDX-License-Identifier: BSD-3-Clause

#include "ginkgo/core/distributed/row_gatherer.hpp"

#include <ginkgo/core/base/dense_cache.hpp>
#include <ginkgo/core/base/event.hpp>
#include <ginkgo/core/distributed/dense_communicator.hpp>
#include <ginkgo/core/distributed/neighborhood_communicator.hpp>
#include <ginkgo/core/distributed/row_scatterer.hpp>
#include <ginkgo/core/distributed/vector.hpp>
#include <ginkgo/core/matrix/dense.hpp>

#include "core/base/dispatch_helper.hpp"
#include "core/base/event_kernels.hpp"
#include "core/distributed/helpers.hpp"

namespace gko {
namespace experimental {
namespace distributed {


namespace event {
namespace {
GKO_REGISTER_OPERATION(record_event, event::record_event);
}
}  // namespace event


template <typename LocalIndexType>
mpi::request RowGatherer<LocalIndexType>::apply_async(ptr_param<const LinOp> b,
                                                      ptr_param<LinOp> x) const
{
    return apply_async(b, x, send_cache_);
}


template <typename LocalIndexType>
mpi::request RowGatherer<LocalIndexType>::apply_async(
    ptr_param<const LinOp> b, ptr_param<LinOp> x,
    gko::detail::GenericDenseCache& workspace) const
{
    auto ev = this->apply_prepare(b, workspace);
    return this->apply_finalize(b, x, ev, workspace);
}

template <typename LocalIndexType>
std::shared_ptr<const gko::detail::Event>
RowGatherer<LocalIndexType>::apply_prepare(ptr_param<const LinOp> b) const
{
    return apply_prepare(b, send_cache_);
}

template <typename LocalIndexType>
std::shared_ptr<const gko::detail::Event>
RowGatherer<LocalIndexType>::apply_prepare(
    ptr_param<const LinOp> b, gko::detail::GenericDenseCache& workspace) const
{
    std::shared_ptr<const gko::detail::Event> ev = nullptr;
    auto exec = this->get_executor();
    auto use_host_buffer =
        mpi::requires_host_buffer(exec, coll_comm_->get_base_communicator());
    auto mpi_exec = use_host_buffer ? exec->get_master() : exec;

    // dispatch global vector
    run<Vector,
#if GINKGO_ENABLE_HALF
        half, std::complex<half>,
#endif
#if GINKGO_ENABLE_BFLOAT16
        bfloat16, std::complex<bfloat16>,
#endif
        double, float, std::complex<double>, std::complex<float>>(
        make_temporary_clone(exec, b).get(), [&](const auto* b_global) {
            using ValueType =
                typename std::decay_t<decltype(*b_global)>::value_type;
            auto b_local = b_global->get_local_vector();

            dim<2> send_size(coll_comm_->get_send_size(),
                             b_local->get_size()[1]);
            auto send_buffer = workspace.get<ValueType>(mpi_exec, send_size);
            b_local->row_gather(&send_idxs_, send_buffer);
            b_local->get_executor()->run(event::make_record_event(ev));
        });
    return ev;
}


template <typename LocalIndexType>
mpi::request RowGatherer<LocalIndexType>::apply_finalize(
    ptr_param<const LinOp> b, ptr_param<LinOp> x,
    std::shared_ptr<const gko::detail::Event> ev) const
{
    auto req = apply_finalize(b, x, ev, send_cache_);
    return req;
}

template <typename LocalIndexType>
mpi::request RowGatherer<LocalIndexType>::apply_finalize(
    ptr_param<const LinOp> b, ptr_param<LinOp> x,
    std::shared_ptr<const gko::detail::Event> ev,
    gko::detail::GenericDenseCache& workspace) const
{
    mpi::request req;

    auto exec = this->get_executor();
    auto use_host_buffer =
        mpi::requires_host_buffer(exec, coll_comm_->get_base_communicator());
    auto mpi_exec = use_host_buffer ? exec->get_master() : exec;

    GKO_THROW_IF_INVALID(
        !use_host_buffer || mpi_exec->memory_accessible(x->get_executor()),
        "The receive buffer uses device memory, but MPI support of device "
        "memory is not available or host buffer were explicitly requested. "
        "Please provide a host buffer or enable MPI support for device "
        "memory.");

    // dispatch global vector. b is only used for its value type and size, so
    // it doesn't need to be cloned to exec
    run<Vector,
#if GINKGO_ENABLE_HALF
        half, std::complex<half>,
#endif
#if GINKGO_ENABLE_BFLOAT16
        bfloat16, std::complex<bfloat16>,
#endif
        double, float, std::complex<double>, std::complex<float>>(
        b.get(), [&](const auto* b_global) {
            using ValueType =
                typename std::decay_t<decltype(*b_global)>::value_type;
            // x is not converted to the precision of b, since a temporary
            // conversion is freed before MPI finishes receiving into it
            auto x_global = gko::as<Vector<ValueType>>(x.get());
            auto b_local = b_global->get_local_vector();

            dim<2> send_size(coll_comm_->get_send_size(),
                             b_local->get_size()[1]);
            auto send_buffer = workspace.get<ValueType>(mpi_exec, send_size);

            auto recv_ptr = x_global->get_local_values();
            auto send_ptr = send_buffer->get_values();
            ev->synchronize();
            mpi::contiguous_type type(b_local->get_size()[1],
                                      mpi::type_impl<ValueType>::get_type());
            req = coll_comm_->i_all_to_all_v(mpi_exec, send_ptr, type.get(),
                                             recv_ptr, type.get());
        });
    return req;
}


namespace detail {


template <typename LocalIndexType>
std::shared_ptr<const gko::detail::Event> apply_prepare(
    const RowGatherer<LocalIndexType>* rg, ptr_param<const LinOp> b)
{
    return rg->apply_prepare(b);
}


template <typename LocalIndexType>
std::shared_ptr<const gko::detail::Event> apply_prepare(
    const RowGatherer<LocalIndexType>* rg, ptr_param<const LinOp> b,
    gko::detail::GenericDenseCache& workspace)
{
    return rg->apply_prepare(b, workspace);
}


template <typename LocalIndexType>
mpi::request apply_finalize(const RowGatherer<LocalIndexType>* rg,
                            ptr_param<const LinOp> b, ptr_param<LinOp> x,
                            std::shared_ptr<const gko::detail::Event> ev)
{
    return rg->apply_finalize(b, x, ev);
}


template <typename LocalIndexType>
mpi::request apply_finalize(const RowGatherer<LocalIndexType>* rg,
                            ptr_param<const LinOp> b, ptr_param<LinOp> x,
                            std::shared_ptr<const gko::detail::Event> ev,
                            gko::detail::GenericDenseCache& workspace)
{
    return rg->apply_finalize(b, x, ev, workspace);
}


#define GKO_DECLARE_TEST_APPLY_PREPARE(IndexType)            \
    std::shared_ptr<const gko::detail::Event> apply_prepare( \
        const RowGatherer<IndexType>*, ptr_param<const LinOp>)

#define GKO_DECLARE_TEST_APPLY_PREPARE_WORKSPACE(IndexType)    \
    std::shared_ptr<const gko::detail::Event> apply_prepare(   \
        const RowGatherer<IndexType>*, ptr_param<const LinOp>, \
        gko::detail::GenericDenseCache&)

#define GKO_DECLARE_TEST_APPLY_FINALIZE(IndexType)                            \
    mpi::request apply_finalize(const RowGatherer<IndexType>* rg,             \
                                ptr_param<const LinOp> b, ptr_param<LinOp> x, \
                                std::shared_ptr<const gko::detail::Event> ev)

#define GKO_DECLARE_TEST_APPLY_FINALIZE_WORKSPACE(IndexType)                  \
    mpi::request apply_finalize(const RowGatherer<IndexType>* rg,             \
                                ptr_param<const LinOp> b, ptr_param<LinOp> x, \
                                std::shared_ptr<const gko::detail::Event> ev, \
                                gko::detail::GenericDenseCache&)

GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(GKO_DECLARE_TEST_APPLY_PREPARE);
GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(GKO_DECLARE_TEST_APPLY_PREPARE_WORKSPACE);
GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(GKO_DECLARE_TEST_APPLY_FINALIZE);
GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(GKO_DECLARE_TEST_APPLY_FINALIZE_WORKSPACE);

#undef GKO_DECLARE_TEST_APPLY_PREPARE
#undef GKO_DECLARE_TEST_APPLY_PREPARE_WORKSPACE
#undef GKO_DECLARE_TEST_APPLY_FINALIZE
#undef GKO_DECLARE_TEST_APPLY_FINALIZE_WORKSPACE


}  // namespace detail


template <typename LocalIndexType>
dim<2> RowGatherer<LocalIndexType>::get_size() const
{
    return size_;
}


template <typename LocalIndexType>
std::shared_ptr<const mpi::CollectiveCommunicator>
RowGatherer<LocalIndexType>::get_collective_communicator() const
{
    return coll_comm_;
}


template <typename LocalIndexType>
template <typename GlobalIndexType>
RowGatherer<LocalIndexType>::RowGatherer(
    std::shared_ptr<const Executor> exec,
    std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm,
    const index_map<LocalIndexType, GlobalIndexType>& imap)
    : PolymorphicObject(exec),
      DistributedBase(coll_comm->get_base_communicator()),
      size_(dim<2>{
          gko::detail::global_add(exec, coll_comm->get_base_communicator(),
                                  imap.get_non_local_size()),
          imap.get_global_size()}),
      coll_comm_(std::move(coll_comm)),
      send_idxs_(exec),
      send_cache_()
{
    // check that the coll_comm_ and imap have the same recv size
    // the same check for the send size is not possible, since the
    // imap doesn't store send indices
    GKO_THROW_IF_INVALID(
        coll_comm_->get_recv_size() == imap.get_non_local_size(),
        "The collective communicator doesn't match the index map.");

    auto inverse_comm = coll_comm_->create_inverse();

    auto mpi_exec =
        mpi::requires_host_buffer(exec, coll_comm_->get_base_communicator())
            ? exec->get_master()
            : exec;
    auto temp_remote_local_idxs =
        make_temporary_clone(mpi_exec, &imap.get_remote_local_idxs());

    send_idxs_.set_executor(mpi_exec);
    send_idxs_.resize_and_reset(coll_comm_->get_send_size());
    inverse_comm
        ->i_all_to_all_v(mpi_exec,
                         temp_remote_local_idxs->get_const_flat_data(),
                         send_idxs_.get_data())
        .wait();
    send_idxs_.set_executor(exec);
}


template <typename LocalIndexType>
const LocalIndexType* RowGatherer<LocalIndexType>::get_const_send_idxs() const
{
    return send_idxs_.get_const_data();
}


template <typename LocalIndexType>
size_type RowGatherer<LocalIndexType>::get_num_send_idxs() const
{
    return send_idxs_.get_size();
}


template <typename LocalIndexType>
std::unique_ptr<RowGatherer<LocalIndexType>>
RowGatherer<LocalIndexType>::create_from_scatterer(
    std::shared_ptr<const Executor> exec,
    ptr_param<const RowScatterer<LocalIndexType>> scatterer)
{
    auto inverse_comm =
        scatterer->get_collective_communicator()->create_inverse();

    // The send_idxs_ for the gatherer are the recv_idxs_ of the scatterer
    auto num_recv_idxs = scatterer->get_num_recv_idxs();
    array<LocalIndexType> send_idxs(exec, num_recv_idxs);
    if (num_recv_idxs > 0) {
        exec->copy_from(scatterer->get_executor(), num_recv_idxs,
                        scatterer->get_const_recv_idxs(), send_idxs.get_data());
    }

    // Size is the transpose of the scatterer's size
    auto scatterer_size = scatterer->get_size();
    dim<2> size{scatterer_size[1], scatterer_size[0]};

    return std::unique_ptr<RowGatherer>(new RowGatherer(
        std::move(exec), std::move(inverse_comm), std::move(send_idxs), size));
}


template <typename LocalIndexType>
std::unique_ptr<RowGatherer<LocalIndexType>>
RowGatherer<LocalIndexType>::create(std::shared_ptr<const Executor> exec,
                                    mpi::communicator comm)
{
    return std::unique_ptr<RowGatherer>(new RowGatherer(
        std::move(exec),
        mpi::detail::create_default_collective_communicator(comm)));
}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>::RowGatherer(std::shared_ptr<const Executor> exec,
                                         mpi::communicator comm)
    : RowGatherer(std::move(exec),
                  mpi::detail::create_default_collective_communicator(comm))
{}


template <typename LocalIndexType>
std::unique_ptr<RowGatherer<LocalIndexType>>
RowGatherer<LocalIndexType>::create(
    std::shared_ptr<const Executor> exec,
    std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm_template)
{
    return std::unique_ptr<RowGatherer>(
        new RowGatherer(std::move(exec), std::move(coll_comm_template)));
}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>::RowGatherer(
    std::shared_ptr<const Executor> exec,
    std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm_template)
    : PolymorphicObject(exec),
      DistributedBase(coll_comm_template->get_base_communicator()),
      coll_comm_(std::move(coll_comm_template)),
      send_idxs_(exec)
{}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>::RowGatherer(
    std::shared_ptr<const Executor> exec,
    std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm,
    array<LocalIndexType> send_idxs, dim<2> size)
    : PolymorphicObject(exec),
      DistributedBase(coll_comm->get_base_communicator()),
      size_(size),
      coll_comm_(std::move(coll_comm)),
      send_idxs_(std::move(send_idxs))
{}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>::RowGatherer(RowGatherer&& o)
    : PolymorphicObject(o.get_executor()),
      DistributedBase(o.get_communicator()),
      send_idxs_(o.get_executor())
{
    *this = std::move(o);
}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>& RowGatherer<LocalIndexType>::operator=(
    const RowGatherer& o)
{
    if (this != &o) {
        size_ = o.get_size();
        coll_comm_ = o.coll_comm_;
        send_idxs_ = o.send_idxs_;
    }
    return *this;
}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>& RowGatherer<LocalIndexType>::operator=(
    RowGatherer&& o)
{
    if (this != &o) {
        size_ = std::exchange(o.size_, dim<2>{});
        coll_comm_ = std::exchange(
            o.coll_comm_, mpi::detail::create_default_collective_communicator(
                              o.get_communicator()));
        send_idxs_ = std::move(o.send_idxs_);
    }
    return *this;
}


template <typename LocalIndexType>
RowGatherer<LocalIndexType>::RowGatherer(const RowGatherer& o)
    : PolymorphicObject(o.get_executor()),
      DistributedBase(o.get_communicator()),
      send_idxs_(o.get_executor())
{
    *this = o;
}


#define GKO_DECLARE_ROW_GATHERER(IndexType) class RowGatherer<IndexType>

GKO_INSTANTIATE_FOR_EACH_INDEX_TYPE(GKO_DECLARE_ROW_GATHERER);

#undef GKO_DECLARE_ROW_GATHERER


#define GKO_DECLARE_ROW_GATHERER_CONSTRUCTOR(_ltype, _gtype)          \
    RowGatherer<_ltype>::RowGatherer(                                 \
        std::shared_ptr<const Executor> exec,                         \
        std::shared_ptr<const mpi::CollectiveCommunicator> coll_comm, \
        const index_map<_ltype, _gtype>& imap)

GKO_INSTANTIATE_FOR_EACH_LOCAL_GLOBAL_INDEX_TYPE(
    GKO_DECLARE_ROW_GATHERER_CONSTRUCTOR);

#undef GKO_DECLARE_ROW_GATHERER_CONSTRUCTOR
}  // namespace distributed
}  // namespace experimental
}  // namespace gko
