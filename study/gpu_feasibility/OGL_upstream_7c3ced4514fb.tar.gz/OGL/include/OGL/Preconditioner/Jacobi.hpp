// SPDX-FileCopyrightText: 2025 OGL authors
//
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "OGL/Preconditioner/Schwarz.hpp"

class BlockJacobi {
    using dbj = gko::preconditioner::Jacobi<double, label>;
    using fbj = gko::preconditioner::Jacobi<float, label>;

    std::shared_ptr<gko::Executor> exec_;
    std::shared_ptr<const gko::LinOp> mtx_;
    const dictionary &d_;
    const label verbose_;
    bool skip_sorting_;
    bool multi_level_schwarz_;
    label max_block_size_;
    word precision_;


public:
    BlockJacobi(std::shared_ptr<gko::Executor> exec,
                std::shared_ptr<const gko::LinOp> mtx, const dictionary &d,
                label verbose)
        : exec_(exec),
          mtx_(mtx),
          d_(d),
          verbose_(verbose),
          skip_sorting_(d.lookupOrDefault<Switch>("skipSorting", true)),
          multi_level_schwarz_(
              d.lookupOrDefault<Switch>("multiLevelSchwarz", false)),
          max_block_size_(d.lookupOrDefault("maxBlockSize", label(1))),
          precision_(d.lookupOrDefault("precision", word("double")))
    {
        word msg =
            "\nGenerate BJ preconditioner:\n\tprecision: " + precision_ +
            "\n\tmaxBlockSize: " + std::to_string(max_block_size_) +
            "\n\tskipSorting: " + Switch(skip_sorting_).c_str() +
            "\n\tmultiLevelSchwarz: " + Switch(multi_level_schwarz_).c_str();
        MLOG_0(verbose_, msg)
    }

    std::shared_ptr<gko::LinOp> create()
    {
        auto builder = [this](auto b) {
            return b.with_skip_sorting(skip_sorting_)
                .with_max_block_size(static_cast<gko::uint32>(max_block_size_))
                .on(exec_);
        };

        if (precision_ == "double") {
            auto b = builder(dbj::build());
            return dispatch_schwarz(
                mtx_, exec_,
                gko::share(
                    b->generate(gko::as<RepartDistMatrix>(mtx_)->get_local())),
                d_, verbose_);
        }
        if (precision_ == "float") {
            auto b = builder(fbj::build());
            return dispatch_schwarz(
                mtx_, exec_,
                gko::share(
                    b->generate(gko::as<RepartDistMatrix>(mtx_)->get_local())),
                d_, verbose_);
        }

        FatalErrorInFunction << "Unknown precision: " << precision_
                             << "\nValid Choices: double, float"
                             << abort(FatalError);
        return {};
    }
};
