// SPDX-FileCopyrightText: 2025 OGL authors
//
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "OGL/Preconditioner/Schwarz.hpp"

class ISAI {
    std::shared_ptr<gko::Executor> exec_;
    std::shared_ptr<const gko::LinOp> mtx_;
    const dictionary &d_;
    const label verbose_;
    bool skip_sorting_;
    bool multi_level_schwarz_;
    word type_;
    label sparsityPower_;


public:
    ISAI(std::shared_ptr<gko::Executor> exec,
         std::shared_ptr<const gko::LinOp> mtx, const dictionary &d,
         label verbose)
        : exec_(exec),
          mtx_(mtx),
          d_(d),
          verbose_(verbose),
          skip_sorting_(d.lookupOrDefault<Switch>("skipSorting", true)),
          multi_level_schwarz_(
              d.lookupOrDefault<Switch>("multiLevelSchwarz", false)),
          type_(d.lookupOrDefault("type", word("SPD"))),
          sparsityPower_(d.lookupOrDefault("sparsityPower", label(1)))
    {
        word msg =
            "\nGenerate ISAI preconditioner:\n\ttype: " + type_ +
            "\n\tsparsityPower: " + std::to_string(sparsityPower_) +
            "\n\tskipSorting: " + Switch(skip_sorting_).c_str() +
            "\n\tmultiLevelSchwarz: " + Switch(multi_level_schwarz_).c_str();
        MLOG_0(verbose_, msg)
    }

    auto generate_precond_factory_spd()
    {
        return gko::preconditioner::Isai<gko::preconditioner::isai_type::spd,
                                         scalar, label>::build()
            .with_skip_sorting(skip_sorting_)
            .with_sparsity_power(sparsityPower_)
            .on(exec_);
    }

    auto generate_precond_factory_general()
    {
        return gko::preconditioner::Isai<
                   gko::preconditioner::isai_type::general, scalar,
                   label>::build()
            .with_skip_sorting(skip_sorting_)
            .with_sparsity_power(sparsityPower_)
            .on(exec_);
    }

    std::shared_ptr<gko::LinOp> create()
    {
        if (type_ == "SPD") {
            auto b = generate_precond_factory_spd();
            return dispatch_schwarz(
                mtx_, exec_,
                gko::share(
                    b->generate(gko::as<RepartDistMatrix>(mtx_)->get_local())),
                d_, verbose_);
        }
        if (type_ == "General") {
            auto b = generate_precond_factory_general();
            return dispatch_schwarz(
                mtx_, exec_,
                gko::share(
                    b->generate(gko::as<RepartDistMatrix>(mtx_)->get_local())),
                d_, verbose_);
        }
        FatalErrorInFunction << "Unknown ISAI type: " << type_
                             << "\nValid Choices: SPD, General"
                             << abort(FatalError);
        return {};
    }
};
