// SPDX-FileCopyrightText: 2024 OGL authors
//
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#include "fvCFD.H"

#include "OGL/DevicePersistent/Base.hpp"

#include <ginkgo/ginkgo.hpp>

namespace Foam {

struct DeviceIdGuardInitFunctor {
    std::shared_ptr<const gko::Executor> executor_;

    DeviceIdGuardInitFunctor(
        const std::shared_ptr<const gko::Executor> executor)
        : executor_(executor)
    {}

    void update(std::shared_ptr<gko::scoped_device_id_guard>) const {}

    std::shared_ptr<gko::scoped_device_id_guard> init() const
    {
        return std::make_shared<gko::scoped_device_id_guard>(
            executor_->get_scoped_device_id_guard());
        // std::move(executor_->get_scoped_device_id_guard()));
    }
};

class DeviceIdGuardHandler : public PersistentBase<gko::scoped_device_id_guard,
                                                   DeviceIdGuardInitFunctor> {
public:
    DeviceIdGuardHandler(const objectRegistry &db, const word field_name,
                         std::shared_ptr<const gko::Executor> executor)
        : PersistentBase<gko::scoped_device_id_guard, DeviceIdGuardInitFunctor>(
              "scoped_device_id_guard_" + field_name, db,
              DeviceIdGuardInitFunctor(executor), true, 0)
    {}
};

}  // namespace Foam
