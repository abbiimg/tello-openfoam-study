// SPDX-FileCopyrightText: 2024 OGL authors
//
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#include <OGL/common.hpp>

#include <ginkgo/ginkgo.hpp>

#include "fvCFD.H"


/* @brief The CombinationMatrix class is a wrapper around Ginkgos combination
 * linear operator. It provides an interface for creating linear combinations of
 * a given inner matrix type and a read implementation
 * */
template <typename InnerMatrixType>
class CombinationMatrix
    : public gko::LinOp,
      public gko::EnableCloneable<CombinationMatrix<InnerMatrixType>>,
      public gko::EnableCreateMethod<CombinationMatrix<InnerMatrixType>>,
      public gko::ReadableFromMatrixData<scalar, label>,
      public gko::ConvertibleTo<gko::matrix::Coo<scalar, label>>,
      public gko::ConvertibleTo<gko::matrix::Csr<scalar, label>>,
      public gko::WritableToMatrixData<scalar, label> {
    friend class gko::EnableCreateMethod<CombinationMatrix<InnerMatrixType>>;
    friend class gko::EnableCloneable<CombinationMatrix<InnerMatrixType>>;

public:
    using gko::EnableCloneable<CombinationMatrix<InnerMatrixType>>::convert_to;
    using gko::EnableCloneable<CombinationMatrix<InnerMatrixType>>::move_to;

    using matrix_data = gko::matrix_data<scalar, label>;

    void read([[maybe_unused]] const matrix_data &data) override
    {
        FatalErrorInFunction << "Not implemented" << abort(FatalError);
    }

    std::shared_ptr<gko::Combination<scalar>> get_combination() const
    {
        return this->comb_;
    }

    /**
     * Copy-assigns a CombinationMatrix matrix. Preserves executor, copies
     * everything else.
     */
    CombinationMatrix &operator=(const CombinationMatrix &other)
    {
        if (&other != this) {
            gko::LinOp::operator=(other);
            comb_ = other.comb_;
        }
        return *this;
    }

    /**
     * Move-assigns a CombinationMatrix matrix. Preserves executor, moves the
     * data and leaves the moved-from object in an empty state (0x0 LinOp with
     * unchanged executor and strategy, no nonzeros and valid row pointers).
     */
    CombinationMatrix &operator=(CombinationMatrix &&other)
    {
        if (&other != this) {
            gko::LinOp::operator=(std::move(other));
            comb_ = std::move(other.comb_);
        }
        return *this;
    }


    void write(gko::matrix_data<scalar, label> &res) const override
    {
        auto exec = this->get_executor();
        auto operators = this->get_operators();

        std::vector<gko::matrix_data_entry<scalar, label>> data;
        for (auto op : operators) {
            auto tmp_mat_data = gko::matrix_data<scalar, label>();
            gko::as<InnerMatrixType>(op)->write(tmp_mat_data);
            data.insert(data.end(), tmp_mat_data.nonzeros.begin(),
                        tmp_mat_data.nonzeros.end());
        }
        auto mat_data = gko::matrix_data<scalar, label>();
        res.nonzeros = data;
        res.size = this->get_size();
    }


    /**
     * Returns a list of coefficients of the combination.
     *
     * @return a list of coefficients
     */
    const std::vector<std::shared_ptr<const gko::LinOp>> &get_coefficients()
        const noexcept
    {
        return comb_->get_coefficients();
    }

    /**
     * Returns a list of operators of the combination.
     *
     * @return a list of operators
     */
    const std::vector<std::shared_ptr<const gko::LinOp>> &get_operators()
        const noexcept
    {
        return comb_->get_operators();
    }

    /*
     * @warning assumes that all entries are unique
     */
    void convert_to(gko::matrix::Coo<scalar, label> *result) const override
    {
        auto exec = this->get_executor();
        auto operators = this->get_operators();

        std::vector<gko::matrix_data_entry<scalar, label>> data;
        for (auto op : operators) {
            auto tmp_mat_data = gko::matrix_data<scalar, label>();
            gko::as<InnerMatrixType>(op)->write(tmp_mat_data);
            data.insert(data.end(), tmp_mat_data.nonzeros.begin(),
                        tmp_mat_data.nonzeros.end());
        }
        auto mat_data = gko::matrix_data<scalar, label>();
        mat_data.nonzeros = data;
        mat_data.size = this->get_size();

        result->read(mat_data);
    }

    /*
     * @warning assumes that all entries are unique
     */
    void convert_to(gko::matrix::Csr<scalar, label> *result) const override
    {
        auto exec = this->get_executor();
        auto operators = this->get_operators();

        std::vector<gko::matrix_data_entry<scalar, label>> data;
        for (auto op : operators) {
            auto tmp_mat_data = gko::matrix_data<scalar, label>();
            gko::as<InnerMatrixType>(op)->write(tmp_mat_data);
            data.insert(data.end(), tmp_mat_data.nonzeros.begin(),
                        tmp_mat_data.nonzeros.end());
        }
        auto mat_data = gko::matrix_data<scalar, label>();
        mat_data.nonzeros = data;
        mat_data.size = this->get_size();

        result->read(mat_data);
    }

    /*
     * @warning assumes that all entries are unique
     */
    void move_to(gko::matrix::Coo<scalar, label> *result) override
    {
        this->convert_to(result);
        this->comb_ = nullptr;
        this->set_size(gko::dim<2>(0, 0));
    }

    /*
     * @warning assumes that all entries are unique
     */
    void move_to(gko::matrix::Csr<scalar, label> *result) override
    {
        this->convert_to(result);
        this->comb_ = nullptr;
        this->set_size(gko::dim<2>(0, 0));
    }

protected:
    CombinationMatrix(std::shared_ptr<const gko::Executor> exec)
        : gko::LinOp(exec),
          comb_(gko::share(gko::Combination<scalar>::create(exec)))
    {}

    CombinationMatrix(std::shared_ptr<const gko::Executor> exec,
                      gko::dim<2> size,
                      std::vector<std::shared_ptr<gko::LinOp>> operators)
        : gko::LinOp(exec), comb_(build_combination(exec, size, operators))
    {
        this->set_size(size);
    }

    static std::shared_ptr<gko::Combination<scalar>> build_combination(
        std::shared_ptr<const gko::Executor> exec, gko::dim<2> size,
        const std::vector<std::shared_ptr<gko::LinOp>> &operators)
    {
        if (size[1] == 0 || operators.empty()) {
            return gko::share(gko::Combination<scalar>::create(exec));
        }
        std::vector<std::shared_ptr<const gko::LinOp>> coeffs;
        std::vector<std::shared_ptr<const gko::LinOp>> ops;
        coeffs.reserve(operators.size());
        ops.reserve(operators.size());
        for (const auto &op : operators) {
            coeffs.push_back(
                gko::initialize<gko::matrix::Dense<scalar>>({1}, exec));
            ops.push_back(op);
        }
        return gko::share(gko::Combination<scalar>::create(
            coeffs.begin(), coeffs.end(), ops.begin(), ops.end()));
    }

    /* Forwarding call of apply which checks if the matrix contains any
     * submatrices
     * */
    void apply_impl(const gko::LinOp *b, gko::LinOp *x) const override
    {
        if (this->get_size()[0] > 0 && this->get_size()[1] > 0) {
            // SIMPLE_TIME(1, combination_apply, this->comb_->apply(b, x););
            this->comb_->apply(b, x);
        }
    }

    /* Forwarding call of apply which checks if the matrix contains any
     * submatrices
     * */
    void apply_impl(const gko::LinOp *alpha, const gko::LinOp *b,
                    const gko::LinOp *beta, gko::LinOp *x) const override
    {
        if (this->get_size()[0] > 0 && this->get_size()[1] > 0) {
            // SIMPLE_TIME(1,
            // combination_advanced_apply,this->comb_->apply(alpha, b, beta,
            // x););
            this->comb_->apply(alpha, b, beta, x);
        }
    }

private:
    std::vector<std::shared_ptr<gko::LinOp>> coeffs_;  //
    std::shared_ptr<gko::Combination<scalar>> comb_;
};

namespace detail {
std::shared_ptr<gko::matrix::Coo<scalar, label>> convert_combination_to_coo(
    std::shared_ptr<const gko::Executor> exec,
    std::shared_ptr<const gko::LinOp> in);
}  // namespace detail
